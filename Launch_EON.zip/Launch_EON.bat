@echo off
:: Путь до Electron (если установлен глобально)
set ELECTRON_CMD="C:\Users\%USERNAME%\AppData\Roaming\npm\electron.cmd"

:: Путь до папки с твоей сборкой ChatGPT
set APP_PATH=E:\Eon\ChatGPT_unpack

:: Запуск приложения
pushd "%APP_PATH%"
%ELECTRON_CMD% .
popd
pause