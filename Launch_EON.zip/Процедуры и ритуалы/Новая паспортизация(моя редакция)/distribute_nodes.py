"""
distribute_nodes.py

Постобработка узлов:
1) Читает паспорт, извлекает строку "🎯 Тема:" и обновляет registry.csv (код = номер строки).
2) Читает chats/curr_nodes.md и для каждого узла
   - определяет артефакт/слой по префиксам перед ⭐️ (если есть, добавлены рукой на этапе маркировки),
   - переносит в processing/* и memory/memory.md,
   - при переносе в processing добавляет префикс "<code><artifact><layer> " и **удаляет** обрамление ⭐️ … 🔸.
3) Обновляет "## 📊 Метрика" и "## 🔗 Anchors" в chats/curr_pass.md.
4) Пишет события в backpack_log.md.
"""

import os, re, csv, datetime

CHATS = "chats"
PROCESSING = "processing"
MEMORY_FILE = os.path.join("memory", "memory.md")
PASSPORT = os.path.join(CHATS, "curr_pass.md")
NODES = os.path.join(CHATS, "curr_nodes.md")
LOG = "backpack_log.md"
REGISTRY = "registry.csv"

ARTIFACT_MAP = {
    "💎": os.path.join(PROCESSING, "crystals.md"),
    "💡": os.path.join(PROCESSING, "ideas.md"),
    "🪬": os.path.join(PROCESSING, "amulets.md"),
    "🜂": os.path.join(PROCESSING, "intentions.md"),
    "📝": os.path.join(PROCESSING, "drafts.md"),
    "✨": os.path.join(PROCESSING, "sparks.md"),
}
MEMORY_HEADINGS = {
    "💭": "## 💭 Краткосрочная",
    "📋": "## 📋 Среднесрочная",
    "🗄": "## 🗄 Долгосрочная",
}
def log_event(action, note):
    ts = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"{ts} | script | distribute_nodes {action}: {note}\n")

def read_text(path):
    if not os.path.exists(path):
        return ""
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def read_lines(path):
    if not os.path.exists(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        return [line.rstrip("\n") for line in f]

def append_line(path, line):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(line.rstrip("\n") + "\n")

def extract_theme(passport_text):
    m = re.search(r"^[ \t]*🎯\s*Тема\s*:\s*(.+)$", passport_text, flags=re.M)
    if m:
        return m.group(1).strip()
    return ""

def ensure_registry():
    if not os.path.exists(REGISTRY):
        with open(REGISTRY, "w", encoding="utf-8", newline="") as f:
            f.write("sid,theme,utc,nodes_total,manual_needed,anchors_total
")
    return
 f"{sid_num:03d}", sid_num

def update_registry(sid, theme, nodes_total, manual_needed, anchors_total):
    ensure_registry()
    now = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    with open(REGISTRY, "a", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow([sid, theme, now, nodes_total, manual_needed, anchors_total])

def extract_prefixes_and_node(line):
    manual = line.strip().startswith("[MANUAL_NEEDED ")
    if manual:
        return (None, None, None, True)
    if "⭐️" not in line:
        return (None, None, None, False)
    pre, rest = line.split("⭐️", 1)
    pre = pre.strip()
    artifact = None
    layer = None
    tokens = [ch for ch in pre if ch.strip()]
    for ch in tokens:
        if artifact is None and ch in ARTIFACT_MAP:
            artifact = ch; continue
        if layer is None and ch in MEMORY_HEADINGS:
            layer = ch; continue
    node_body = rest  # without leading star
    # trim at end marker
    end_idx = node_body.find("🔸")
    if end_idx != -1:
        core = node_body[:end_idx]
    else:
        core = node_body
    core = core.strip()
    return (artifact, layer, core, False)  # core without ⭐️/🔸

def update_memory(memory_path, layer_symbol, code, core_text):
    if not os.path.exists(memory_path):
        os.makedirs(os.path.dirname(memory_path), exist_ok=True)
        with open(memory_path, "w", encoding="utf-8") as f:
            f.write("# Память Эона\n\n## 💭 Краткосрочная\n\n## 📋 Среднесрочная\n\n## 🗄 Долгосрочная\n")
    with open(memory_path, "r", encoding="utf-8") as f:
        text = f.read()
    heading = MEMORY_HEADINGS[layer_symbol]
    if heading not in text:
        if not text.endswith("\n"):
            text += "\n"
        text += f"\n{heading}\n"
    # append line under heading
    pattern = rf"(^##\s+{re.escape(heading[3:])}\s*$)"
    # simple: append at end of file after heading occurrence
    # here we do minimalistic append
    text += f"- {code} {core_text}\n"
    with open(memory_path, "w", encoding="utf-8") as f:
        f.write(text)

def replace_section(passport_path, section_title_variants, new_lines):
    if not os.path.exists(passport_path):
        return
    with open(passport_path, "r", encoding="utf-8") as f:
        text = f.read()
    # ensure section exists (prefer first title)
    title = None
    for t in section_title_variants:
        if re.search(rf"^##\s+{re.escape(t)}\s*$", text, flags=re.M):
            title = t; break
    if title is None:
        if not text.endswith("\n"):
            text += "\n"
        title = section_title_variants[0]
        text += f"\n## {title}\n" + "\n".join(new_lines) + "\n"
    else:
        pattern = rf"(^##\s+{re.escape(title)}\s*$)(.*?)(?=^\#\#\s+|\Z)"
        def repl(m):
            return m.group(1) + "\n" + "\n".join(new_lines) + "\n"
        text = re.sub(pattern, repl, text, flags=re.M|re.S)
    with open(passport_path, "w", encoding="utf-8") as f:
        f.write(text)

def main():
    log_event("start", "begin distribution with registry")
    passport_text = read_text(PASSPORT)
    theme = extract_theme(passport_text)
    code, sid_num = assign_sid()

    # Read nodes
    lines = read_lines(NODES)
    if not lines:
        log_event("error", "curr_nodes.md missing or empty")
        print("Нет узлов для обработки.")
        return

    total = 0
    manual = 0
    art_count = {k:0 for k in ARTIFACT_MAP.keys()}
    layer_count = {k:0 for k in MEMORY_HEADINGS.keys()}
    unmarked = 0
    anchors = {}

    for line in lines:
        artifact, layer, core_text, is_manual = extract_prefixes_and_node(line)
        if is_manual or core_text is None:
            manual += 1
            continue
        total += 1
        # collect anchors
        for a in re.findall(r"`([A-Za-z0-9_\-]+)", core_text):
            anchors[a] = anchors.get(a, 0) + 1
        # distribute only marked nodes; if both None, count as unmarked
        if artifact is None and layer is None:
            unmarked += 1
        # distribute to artifact file
        if artifact in ARTIFACT_MAP:
            out_line = f"{sid}{artifact or ''}{layer or ''} {core_text}"
            append_line(ARTIFACT_MAP[artifact], out_line)
            art_count[artifact] += 1
        # distribute to memory
        if layer in MEMORY_HEADINGS:
            update_memory(MEMORY_FILE, layer, sid, core_text)
            layer_count[layer] += 1

    # Metrics/Anchors sections
    metrics_lines = [
        f"- sid: {code}",
        f"- nodes_total: {total}",
        f"- marked: {total - unmarked}",
        f"- unmarked: {unmarked}",
        f"- manual_needed: {manual}",
        "- by_artifact: " + ", ".join(f"{k}:{art_count[k]}" for k in ["💎","💡","🪬","🜂","📝","✨"]),
        "- by_memory: " + ", ".join(f"{k}:{layer_count[k]}" for k in ["💭","📋","🗄"]),
    ]
    top = sorted(anchors.items(), key=lambda kv: (-kv[1], kv[0]))
    anchors_lines = [f"- `{a}` — {c}" for a,c in top[:50]] or ["- —"]

    replace_section(PASSPORT, ["📊 Метрика","Метрика"], metrics_lines)
    replace_section(PASSPORT, ["🔗 Anchors","Anchors","Anchors (топ)"], anchors_lines)

    # Update registry at the end with actual totals
    update_registry(sid, theme, total, manual, len(anchors))

    log_event("done", f"distributed sid={code}, nodes={total}, manual={manual}, anchors={len(anchors)}")
    print(f"Готово: sid={code}, nodes_total={total}, manual_needed={manual}, anchors={len(anchors)}")

if __name__ == "__main__":
    main()
