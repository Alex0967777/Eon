"""
pairs_parser.py

Скрипт для выделения узлов (⭐️ … 🔸) из стенограммы чата.
Описание механики: scripts/pairs_parser_desc.md

Особенности:
- Работает с рабочей копией chats/curr_chat.work.txt (FIFO-удаление обработанных пар).
- Каждые 5 пар без ⭐️ — мягкая пауза: состояние пишется в scripts/state/pairs_parser_state.json и скрипт завершается.
- Повторный запуск продолжает с места остановки.

Переменные окружения (необязательные):
- BACKPACK_CHATS_DIR (по умолчанию 'chats')
- BACKPACK_SCRIPTS_DIR (по умолчанию 'scripts')
"""

import os, re, json, time
from datetime import datetime

CHATS_DIR = os.environ.get('BACKPACK_CHATS_DIR', 'chats')
SCRIPTS_DIR = os.environ.get('BACKPACK_SCRIPTS_DIR', 'scripts')
WORK_FILE = os.path.join(CHATS_DIR, 'curr_chat.work.txt')
INPUT_FILE = os.path.join(CHATS_DIR, 'curr_chat.txt')
NODES_FILE = os.path.join(CHATS_DIR, 'curr_nodes.md')
STATE_DIR = os.path.join(SCRIPTS_DIR, 'state')
STATE_FILE = os.path.join(STATE_DIR, 'pairs_parser_state.json')

def get_next_n(nodes_file):
    nmax = 0
    if os.path.exists(nodes_file):
        with open(nodes_file, 'r', encoding='utf-8') as f:
            for line in f:
                m = re.match(r'^\[N:(\d+)\]', line)
                if m:
                    nmax = max(nmax, int(m.group(1)))
    return nmax + 1


PAIR_SPLIT_RE = re.compile(r"Вы сказали:(.*?)ChatGPT сказал:(.*?)(?=\nВы сказали:|\Z)", re.S)

def ensure_dirs():
    os.makedirs(CHATS_DIR, exist_ok=True)
    os.makedirs(STATE_DIR, exist_ok=True)

def load_text(path):
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()

def save_text(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(text)

def append_lines(path, lines):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'a', encoding='utf-8') as f:
        for line in lines:
            f.write(line.rstrip('\n') + '\n')

def split_pairs(text):
    return PAIR_SPLIT_RE.findall(text)

def extract_nodes(eon_part: str):
    # New standard: extract all ⭐️…🔸 segments (non-greedy)
    matches = re.findall(r'⭐️.*?🔸', eon_part, flags=re.S)
    if matches:
        return [m.strip() for m in matches]
    # Legacy: if ⭐️ exists but no 🔸 → one node from first ⭐️ to end
    if '⭐️' in eon_part:
        start = eon_part.find('⭐️')
        return [eon_part[start:].strip()]
    return []

def rebuild_text_from_pairs(pairs):
    # Собираем обратно форматированную стенограмму
    out = []
    for (u, e) in pairs:
        out.append('Вы сказали:' + u.strip() + '\nChatGPT сказал:' + e.strip() + '\n')
    return '\n'.join(out).strip() + ('\n' if out else '')

def read_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def write_state(**kwargs):
    st = read_state()
    st.update(kwargs)
    st['ts'] = datetime.utcnow().isoformat() + 'Z'
    os.makedirs(STATE_DIR, exist_ok=True)
    with open(STATE_FILE, 'w', encoding='utf-8') as f:
        json.dump(st, f, ensure_ascii=False, indent=2)

def main():
    log_event('script', 'pairs_parser start')
    ensure_dirs()

    if not os.path.exists(INPUT_FILE):
        print('Файл не найден:', INPUT_FILE)
        return

    # Подготовка рабочей копии
    if not os.path.exists(WORK_FILE):
        save_text(WORK_FILE, load_text(INPUT_FILE))

    work_text = load_text(WORK_FILE)
    pairs = split_pairs(work_text)
    total_pairs = len(pairs)
    if total_pairs == 0:
        print('Пар не найдено. Проверьте формат стенограммы.')
        write_state(total_pairs=0, processed=0, remaining=0, paused=False)
        return

    nodes_added = []
    manual_without_star = 0
    processed_pairs = 0

    for i, (user_part, eon_part) in enumerate(pairs, 1):
        nodes_found = extract_nodes(eon_part)
        if not nodes_found:
            manual_without_star += 1
            nodes_added.append(f"[MANUAL_NEEDED pair={i}]")
            processed_pairs += 1
            if manual_without_star % 5 == 0:
                # Пауза: фиксируем прогресс, выходим
                remaining_pairs = pairs[i:]
                save_text(WORK_FILE, rebuild_text_from_pairs(remaining_pairs))
                append_lines(NODES_FILE, nodes_added)
                write_state(total_pairs=total_pairs,
                            processed=processed_pairs,
                            remaining=len(remaining_pairs),
                            paused=True,
                            reason='manual_pause_every_5')
                print('Выделил часть пар без ⭐️. Пауза для подтверждения. Продолжим?')
                log_event('script', 'pairs_parser pause after 5 manual-needed')
                return
        else:
            # prepend node headers and append all
            
            # Determine starting N and write headers
            nodes_added.extend(nodes_found)


    # Если дошли сюда — обработали всё без пауз
    append_lines(NODES_FILE, nodes_added)
    save_text(WORK_FILE, '')  # всё обработано
    write_state(total_pairs=total_pairs, processed=processed_pairs, remaining=0, paused=False)
    print(f'Готово. Найдено пар: {total_pairs}. Узлов добавлено: {len(nodes_added)}. Остаток: 0.')
    log_event('script', f'pairs_parser done; pairs={total_pairs}; nodes={len(nodes_added)}')

if __name__ == '__main__':
    main()


def log_event(action: str, note: str):
    # Append one line to root backpack log
    try:
        import datetime
        ts = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
        with open("backpack_log.md", "a", encoding="utf-8") as lf:
            lf.write(f"{ts} | {action} | {note}\n")
    except Exception:
        pass

